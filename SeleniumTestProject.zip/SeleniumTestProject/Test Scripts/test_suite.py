from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Initialize Chrome
driver = webdriver.Chrome()
driver.maximize_window()

# ------------------------------
# 1️⃣ Login Test
# ------------------------------
driver.get("http://localhost:3000/login.html")
driver.find_element(By.NAME, "email").send_keys("test@example.com")
driver.find_element(By.NAME, "password").send_keys("123456")
driver.find_element(By.ID, "loginBtn").click()

try:
    WebDriverWait(driver, 10).until(EC.url_contains("index.html"))
    print("Login Test Passed ✅")
except:
    print("Login Test Failed ❌")

# ------------------------------
# 2️⃣ Signup Test
# ------------------------------
driver.get("http://localhost:3000/signup.html")
driver.find_element(By.NAME, "email").send_keys("newuser@example.com")
driver.find_element(By.NAME, "password").send_keys("password123")
driver.find_element(By.ID, "signupBtn").click()

try:
    WebDriverWait(driver, 10).until(EC.alert_is_present())
    alert = driver.switch_to.alert
    print("Signup Alert:", alert.text)
    alert.accept()
    WebDriverWait(driver, 10).until(EC.url_contains("login.html"))
    print("Signup Test Passed ✅")
except:
    print("Signup Test Failed ❌")

# ------------------------------
# 3️⃣ Home Page Test
# ------------------------------
driver.get("http://localhost:3000/index.html")
print("Home page opened:", driver.title)

# ------------------------------
# 4️⃣ About Page Test
# ------------------------------
driver.get("http://localhost:3000/about.html")
print("About page opened:", driver.title)

# ------------------------------
# 5️⃣ Contact Page Test
# ------------------------------
driver.get("http://localhost:3000/contact.html")
print("Contact page opened:", driver.title)

# Finish
driver.quit()
print("All tests completed ✅")