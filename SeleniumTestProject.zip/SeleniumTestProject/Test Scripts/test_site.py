from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 1️⃣ Open Chrome
driver = webdriver.Chrome()  # Selenium finds chromedriver.exe from PATH

# 2️⃣ Open login page
driver.get("http://localhost:3000/login.html")
driver.maximize_window()

# 3️⃣ Enter login credentials
driver.find_element(By.NAME, "email").send_keys("test@example.com")
driver.find_element(By.NAME, "password").send_keys("123456")

# 4️⃣ Click login button
driver.find_element(By.ID, "loginBtn").click()

# 5️⃣ Wait until redirected to Home page
try:
    WebDriverWait(driver, 10).until(EC.url_contains("index.html"))
    print("Login Test Passed ✅")
except:
    print("Login Test Failed ❌")

# 6️⃣ Navigate to About page
driver.get("http://localhost:3000/about.html")
print("About page opened:", driver.title)

# 7️⃣ Navigate to Contact page
driver.get("http://localhost:3000/contact.html")
print("Contact page opened:", driver.title)

# 8️⃣ Close the browser
driver.quit()